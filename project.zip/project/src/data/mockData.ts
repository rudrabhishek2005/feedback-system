import { Feedback, User } from '../types';

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah@company.com',
    role: 'manager',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
  },
  {
    id: '2',
    name: 'Mike Chen',
    email: 'mike@company.com',
    role: 'employee',
    managerId: '1',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
  },
  {
    id: '3',
    name: 'Emma Davis',
    email: 'emma@company.com',
    role: 'employee',
    managerId: '1',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
  },
  {
    id: '4',
    name: 'David Wilson',
    email: 'david@company.com',
    role: 'manager',
    avatar: 'https://images.pexels.com/photos/697509/pexels-photo-697509.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
  },
  {
    id: '5',
    name: 'Lisa Anderson',
    email: 'lisa@company.com',
    role: 'employee',
    managerId: '4',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2'
  }
];

export const mockFeedback: Feedback[] = [
  {
    id: '1',
    managerId: '1',
    employeeId: '2',
    strengths: 'Mike consistently delivers high-quality code and shows excellent problem-solving skills. His attention to detail and ability to work collaboratively make him a valuable team member.',
    improvements: 'Could benefit from taking more initiative in meetings and sharing technical insights with the team. Consider leading a small project to develop leadership skills.',
    sentiment: 'positive',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
    acknowledged: true,
    acknowledgedAt: '2024-01-16T09:30:00Z',
    managerName: 'Sarah Johnson',
    employeeName: 'Mike Chen'
  },
  {
    id: '2',
    managerId: '1',
    employeeId: '3',
    strengths: 'Emma has shown remarkable growth in her communication skills and has become the go-to person for client interactions. Her positive attitude is infectious.',
    improvements: 'Technical skills could use some strengthening, particularly in backend development. Recommend additional training or pair programming sessions.',
    sentiment: 'positive',
    createdAt: '2024-01-10T14:30:00Z',
    updatedAt: '2024-01-10T14:30:00Z',
    acknowledged: false,
    managerName: 'Sarah Johnson',
    employeeName: 'Emma Davis'
  },
  {
    id: '3',
    managerId: '4',
    employeeId: '5',
    strengths: 'Lisa demonstrates strong analytical thinking and has significantly improved our testing processes. Her documentation is thorough and well-organized.',
    improvements: 'Time management could be improved. Sometimes takes longer than expected on tasks. Would benefit from breaking down large tasks into smaller, manageable chunks.',
    sentiment: 'neutral',
    createdAt: '2024-01-08T16:15:00Z',
    updatedAt: '2024-01-08T16:15:00Z',
    acknowledged: true,
    acknowledgedAt: '2024-01-09T11:00:00Z',
    managerName: 'David Wilson',
    employeeName: 'Lisa Anderson'
  },
  {
    id: '4',
    managerId: '1',
    employeeId: '2',
    strengths: 'Great collaboration during the recent sprint. Mike stepped up to help team members and showed excellent mentoring abilities.',
    improvements: 'Could work on presenting ideas more confidently in stakeholder meetings. Practice public speaking to build confidence.',
    sentiment: 'positive',
    createdAt: '2024-01-05T11:45:00Z',
    updatedAt: '2024-01-05T11:45:00Z',
    acknowledged: true,
    acknowledgedAt: '2024-01-05T15:20:00Z',
    managerName: 'Sarah Johnson',
    employeeName: 'Mike Chen'
  }
];