import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { mockUsers, mockFeedback } from '../data/mockData';
import { Users, MessageSquare, Plus, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const Team: React.FC = () => {
  const { user } = useAuth();
  
  // Get team members for this manager
  const teamMembers = mockUsers.filter(u => u.managerId === user?.id);
  
  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'negative':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      default:
        return <Minus className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'bg-green-100 text-green-800';
      case 'negative':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Team</h1>
          <p className="text-gray-600">Manage your team members and their feedback</p>
        </div>
        <Link
          to="/feedback"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4 mr-2" />
          Give Feedback
        </Link>
      </div>

      {teamMembers.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border p-12 text-center">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Team Members</h3>
          <p className="text-gray-500">You don't have any team members assigned yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teamMembers.map((member) => {
            const memberFeedback = mockFeedback.filter(f => f.employeeId === member.id);
            const latestFeedback = memberFeedback.sort((a, b) => 
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            )[0];
            const sentimentCounts = memberFeedback.reduce((acc, feedback) => {
              acc[feedback.sentiment] = (acc[feedback.sentiment] || 0) + 1;
              return acc;
            }, {} as Record<string, number>);
            
            return (
              <div key={member.id} className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow">
                <div className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">{member.name}</h3>
                      <p className="text-sm text-gray-500">{member.email}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Total Feedback</span>
                      <span className="font-medium text-gray-900">{memberFeedback.length}</span>
                    </div>

                    {latestFeedback && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Latest Sentiment</span>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium capitalize ${getSentimentColor(latestFeedback.sentiment)}`}>
                          {getSentimentIcon(latestFeedback.sentiment)}
                          <span className="ml-1">{latestFeedback.sentiment}</span>
                        </span>
                      </div>
                    )}

                    {memberFeedback.length > 0 && (
                      <div className="pt-3 border-t">
                        <p className="text-xs text-gray-500 mb-2">Sentiment Breakdown</p>
                        <div className="flex space-x-4 text-xs">
                          <span className="text-green-600">
                            Positive: {sentimentCounts.positive || 0}
                          </span>
                          <span className="text-yellow-600">
                            Neutral: {sentimentCounts.neutral || 0}
                          </span>
                          <span className="text-red-600">
                            Negative: {sentimentCounts.negative || 0}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 flex space-x-2">
                    <Link
                      to={`/feedback?employee=${member.id}`}
                      className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
                    >
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Give Feedback
                    </Link>
                    <button className="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                      View History
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Team;