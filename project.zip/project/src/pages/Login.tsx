import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { MessageSquare, Eye, EyeOff, Users, User, ArrowRight } from 'lucide-react';

const Login: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<'manager' | 'employee' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { user, login } = useAuth();
  const navigate = useNavigate();

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  const handleRoleSelect = (role: 'manager' | 'employee') => {
    setSelectedRole(role);
    setError('');
    // Clear form when switching roles
    setEmail('');
    setPassword('');
  };

  const handleBackToRoleSelection = () => {
    setSelectedRole(null);
    setEmail('');
    setPassword('');
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const success = await login(email, password);
    
    if (success) {
      navigate('/dashboard');
    } else {
      setError('Invalid email or password. Please check your credentials and try again.');
    }
    
    setIsLoading(false);
  };

  const handleDemoLogin = (demoEmail: string) => {
    setEmail(demoEmail);
    setPassword('password');
  };

  // Demo accounts based on role
  const demoAccounts = {
    manager: [
      { email: 'sarah@company.com', name: 'Sarah Johnson' },
      { email: 'david@company.com', name: 'David Wilson' }
    ],
    employee: [
      { email: 'mike@company.com', name: 'Mike Chen' },
      { email: 'emma@company.com', name: 'Emma Davis' },
      { email: 'lisa@company.com', name: 'Lisa Anderson' }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex justify-center items-center space-x-2 mb-4">
            <MessageSquare className="h-12 w-12 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">FeedbackFlow</h1>
          </div>
          <p className="text-gray-600">Team feedback made simple</p>
        </div>

        {!selectedRole ? (
          /* Role Selection */
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 text-center">
              Choose Your Role
            </h2>
            <div className="space-y-4">
              <button
                onClick={() => handleRoleSelect('manager')}
                className="w-full flex items-center justify-between p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-blue-100 rounded-full group-hover:bg-blue-200 transition-colors">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-lg font-medium text-gray-900">Manager</h3>
                    <p className="text-sm text-gray-500">Give feedback to your team members</p>
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-blue-600 transition-colors" />
              </button>

              <button
                onClick={() => handleRoleSelect('employee')}
                className="w-full flex items-center justify-between p-6 border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all group"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-green-100 rounded-full group-hover:bg-green-200 transition-colors">
                    <User className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-lg font-medium text-gray-900">Employee</h3>
                    <p className="text-sm text-gray-500">View and acknowledge your feedback</p>
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-green-600 transition-colors" />
              </button>
            </div>
          </div>
        ) : (
          /* Login Form */
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                Login as {selectedRole === 'manager' ? 'Manager' : 'Employee'}
              </h2>
              <button
                onClick={handleBackToRoleSelection}
                className="text-sm text-blue-600 hover:text-blue-800 transition-colors"
              >
                Change Role
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="mt-1 relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 pr-10"
                    placeholder="Enter your password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-gray-400" />
                    ) : (
                      <Eye className="h-5 w-5 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-md p-3">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin -ml-1 mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Signing in...
                  </div>
                ) : (
                  'Sign in'
                )}
              </button>
            </form>
          </div>
        )}

        {/* Demo Accounts */}
        {selectedRole && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-sm font-medium text-gray-700 mb-3">
              Demo {selectedRole === 'manager' ? 'Manager' : 'Employee'} Accounts
            </h3>
            <p className="text-xs text-gray-500 mb-3">Password: "password" for all accounts</p>
            <div className="space-y-2">
              {demoAccounts[selectedRole].map((account, index) => (
                <button
                  key={index}
                  onClick={() => handleDemoLogin(account.email)}
                  className="w-full text-left px-3 py-2 text-sm bg-gray-50 hover:bg-gray-100 rounded transition-colors"
                >
                  <span className="font-medium">{account.name}</span>
                  <br />
                  <span className="text-gray-500 text-xs">{account.email}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Login;