import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { mockUsers, mockFeedback } from '../data/mockData';
import { FeedbackFormData } from '../types';
import { MessageSquare, Send, User, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const Feedback: React.FC = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const selectedEmployeeId = searchParams.get('employee');
  const teamMembers = mockUsers.filter(u => u.managerId === user?.id);
  
  const [selectedEmployee, setSelectedEmployee] = useState<string>(selectedEmployeeId || '');
  const [formData, setFormData] = useState<FeedbackFormData>({
    strengths: '',
    improvements: '',
    sentiment: 'neutral'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployee || !formData.strengths.trim() || !formData.improvements.trim()) {
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      // Reset form
      setFormData({
        strengths: '',
        improvements: '',
        sentiment: 'neutral'
      });
      setSelectedEmployee('');
      navigate('/team');
    }, 1500);
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'negative':
        return <TrendingDown className="h-5 w-5 text-red-500" />;
      default:
        return <Minus className="h-5 w-5 text-yellow-500" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'border-green-300 bg-green-50';
      case 'negative':
        return 'border-red-300 bg-red-50';
      default:
        return 'border-yellow-300 bg-yellow-50';
    }
  };

  // Get previous feedback for selected employee
  const selectedEmployeeFeedback = selectedEmployee 
    ? mockFeedback
        .filter(f => f.employeeId === selectedEmployee)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 3)
    : [];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Give Feedback</h1>
        <p className="text-gray-600">Provide structured feedback to help your team members grow</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Feedback Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Employee Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Team Member
                </label>
                <select
                  value={selectedEmployee}
                  onChange={(e) => setSelectedEmployee(e.target.value)}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                >
                  <option value="">Choose a team member...</option>
                  {teamMembers.map((member) => (
                    <option key={member.id} value={member.id}>
                      {member.name} ({member.email})
                    </option>
                  ))}
                </select>
              </div>

              {/* Strengths */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Strengths
                </label>
                <textarea
                  value={formData.strengths}
                  onChange={(e) => setFormData({ ...formData, strengths: e.target.value })}
                  rows={4}
                  placeholder="What are this person's key strengths? What do they do well?"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>

              {/* Areas for Improvement */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Areas for Improvement
                </label>
                <textarea
                  value={formData.improvements}
                  onChange={(e) => setFormData({ ...formData, improvements: e.target.value })}
                  rows={4}
                  placeholder="What areas could this person focus on for growth and development?"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>

              {/* Sentiment */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Overall Sentiment
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['positive', 'neutral', 'negative'] as const).map((sentiment) => (
                    <label
                      key={sentiment}
                      className={`cursor-pointer rounded-lg border-2 p-4 text-center transition-all ${
                        formData.sentiment === sentiment
                          ? getSentimentColor(sentiment)
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="sentiment"
                        value={sentiment}
                        checked={formData.sentiment === sentiment}
                        onChange={(e) => setFormData({ ...formData, sentiment: e.target.value as any })}
                        className="sr-only"
                      />
                      <div className="flex flex-col items-center space-y-2">
                        {getSentimentIcon(sentiment)}
                        <span className="text-sm font-medium text-gray-900 capitalize">
                          {sentiment}
                        </span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting || !selectedEmployee || !formData.strengths.trim() || !formData.improvements.trim()}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin -ml-1 mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Submit Feedback
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Previous Feedback */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              {selectedEmployee ? 'Previous Feedback' : 'Select an Employee'}
            </h3>
            
            {!selectedEmployee ? (
              <div className="text-center py-8">
                <User className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm text-gray-500">
                  Select a team member to view their feedback history
                </p>
              </div>
            ) : selectedEmployeeFeedback.length === 0 ? (
              <div className="text-center py-8">
                <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm text-gray-500">
                  No previous feedback for this team member
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {selectedEmployeeFeedback.map((feedback) => (
                  <div key={feedback.id} className="border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium capitalize ${
                        feedback.sentiment === 'positive' ? 'bg-green-100 text-green-800' :
                        feedback.sentiment === 'negative' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {getSentimentIcon(feedback.sentiment)}
                        <span className="ml-1">{feedback.sentiment}</span>
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatDate(feedback.createdAt)}
                      </span>
                    </div>
                    <p className="text-xs text-gray-600 line-clamp-3">
                      {feedback.strengths.substring(0, 100)}...
                    </p>
                    {!feedback.acknowledged && (
                      <span className="inline-block mt-2 text-xs text-orange-600 bg-orange-100 px-2 py-1 rounded">
                        Pending acknowledgment
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Feedback;