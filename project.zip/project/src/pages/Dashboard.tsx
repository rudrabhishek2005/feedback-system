import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import ManagerDashboard from '../components/ManagerDashboard';
import EmployeeDashboard from '../components/EmployeeDashboard';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <div>
      {user?.role === 'manager' ? <ManagerDashboard /> : <EmployeeDashboard />}
    </div>
  );
};

export default Dashboard;