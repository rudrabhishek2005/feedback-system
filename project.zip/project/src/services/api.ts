const API_BASE_URL = 'http://localhost:8000/api';

class ApiService {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem('access_token');
  }

  clearToken() {
    this.token = null;
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...options.headers as Record<string, string>,
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'An error occurred' }));
      throw new Error(error.detail || 'Request failed');
    }

    return response.json();
  }

  // Authentication
  async login(email: string, password: string) {
    const response = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    this.token = response.access_token;
    localStorage.setItem('access_token', this.token!);
    return response;
  }

  async logout() {
    await this.request('/auth/logout', { method: 'POST' });
    this.token = null;
    localStorage.removeItem('access_token');
  }

  async getCurrentUser() {
    return this.request('/auth/me');
  }

  // Users
  async getTeamMembers() {
    return this.request('/users/team');
  }

  async getUser(userId: string) {
    return this.request(`/users/${userId}`);
  }

  async createUser(userData: any) {
    return this.request('/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  // Feedback
  async getFeedback() {
    return this.request('/feedback');
  }

  async getFeedbackById(feedbackId: string) {
    return this.request(`/feedback/${feedbackId}`);
  }

  async createFeedback(feedbackData: any) {
    return this.request('/feedback', {
      method: 'POST',
      body: JSON.stringify(feedbackData),
    });
  }

  async updateFeedback(feedbackId: string, feedbackData: any) {
    return this.request(`/feedback/${feedbackId}`, {
      method: 'PUT',
      body: JSON.stringify(feedbackData),
    });
  }

  async acknowledgeFeedback(feedbackId: string) {
    return this.request(`/feedback/${feedbackId}/acknowledge`, {
      method: 'POST',
    });
  }

  async deleteFeedback(feedbackId: string) {
    return this.request(`/feedback/${feedbackId}`, {
      method: 'DELETE',
    });
  }

  // Analytics
  async getDashboardStats() {
    return this.request('/analytics/dashboard');
  }
}

export const apiService = new ApiService();