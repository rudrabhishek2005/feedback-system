from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime
from models import UserRole, SentimentType
import uuid

# User Schemas
class UserBase(BaseModel):
    name: str
    email: EmailStr
    role: UserRole
    avatar_url: Optional[str] = None

class UserCreate(UserBase):
    password: str
    manager_id: Optional[uuid.UUID] = None

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    avatar_url: Optional[str] = None

class User(UserBase):
    id: uuid.UUID
    manager_id: Optional[uuid.UUID] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class UserWithManager(User):
    manager: Optional[User] = None

class UserWithTeam(User):
    team_members: List[User] = []

# Feedback Schemas
class FeedbackBase(BaseModel):
    strengths: str
    improvements: str
    sentiment: SentimentType

class FeedbackCreate(FeedbackBase):
    employee_id: uuid.UUID

class FeedbackUpdate(BaseModel):
    strengths: Optional[str] = None
    improvements: Optional[str] = None
    sentiment: Optional[SentimentType] = None

class Feedback(FeedbackBase):
    id: uuid.UUID
    manager_id: uuid.UUID
    employee_id: uuid.UUID
    acknowledged: bool
    acknowledged_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class FeedbackWithDetails(Feedback):
    manager_name: str
    employee_name: str

# Authentication Schemas
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

# Dashboard Schemas
class SentimentCount(BaseModel):
    positive: int = 0
    neutral: int = 0
    negative: int = 0

class DashboardStats(BaseModel):
    total_feedback: int
    acknowledged_feedback: int
    pending_feedback: int
    sentiment_counts: SentimentCount

class ManagerDashboardStats(DashboardStats):
    team_members_count: int

class EmployeeDashboardStats(DashboardStats):
    pass