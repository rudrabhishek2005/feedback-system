from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from datetime import timedelta
from typing import List
import models
import schemas
import crud
import auth
from database import engine, get_db
import uuid

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Feedback System API",
    description="A lightweight feedback system for team management",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],  # Frontend URLs
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()

@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "Feedback System API is running"}

# Authentication endpoints
@app.post("/api/auth/login", response_model=schemas.Token)
async def login(login_request: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = auth.authenticate_user(db, login_request.email, login_request.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth.create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/auth/me", response_model=schemas.User)
async def get_current_user_info(current_user: models.User = Depends(auth.get_current_user)):
    return current_user

@app.post("/api/auth/logout")
async def logout():
    # In a real implementation, you might want to blacklist the token
    return {"message": "Successfully logged out"}

# User endpoints
@app.post("/api/users", response_model=schemas.User)
async def create_user(
    user: schemas.UserCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.require_role(models.UserRole.MANAGER))
):
    # Check if user already exists
    if crud.get_user_by_email(db, user.email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # If creating an employee, set the current manager as their manager
    if user.role == models.UserRole.EMPLOYEE and not user.manager_id:
        user.manager_id = current_user.id
    
    return crud.create_user(db, user)

@app.get("/api/users/team", response_model=List[schemas.User])
async def get_team_members(
    current_user: models.User = Depends(auth.require_role(models.UserRole.MANAGER)),
    db: Session = Depends(get_db)
):
    return crud.get_team_members(db, current_user.id)

@app.get("/api/users/{user_id}", response_model=schemas.User)
async def get_user(
    user_id: uuid.UUID,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check permissions: users can only see their own data or their team members' data
    if current_user.role == models.UserRole.EMPLOYEE and user.id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    elif current_user.role == models.UserRole.MANAGER:
        if user.id != current_user.id and user.manager_id != current_user.id:
            raise HTTPException(status_code=403, detail="Access denied")
    
    return user

# Feedback endpoints
@app.post("/api/feedback", response_model=schemas.Feedback)
async def create_feedback(
    feedback: schemas.FeedbackCreate,
    current_user: models.User = Depends(auth.require_role(models.UserRole.MANAGER)),
    db: Session = Depends(get_db)
):
    # Verify that the employee belongs to the manager's team
    employee = crud.get_user(db, feedback.employee_id)
    if not employee or employee.manager_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only give feedback to your team members"
        )
    
    return crud.create_feedback(db, feedback, current_user.id)

@app.get("/api/feedback", response_model=List[schemas.FeedbackWithDetails])
async def get_feedback(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role == models.UserRole.MANAGER:
        feedback_list = crud.get_feedback_by_manager(db, current_user.id)
    else:
        feedback_list = crud.get_feedback_for_employee(db, current_user.id)
    
    # Convert to response format with manager and employee names
    result = []
    for feedback in feedback_list:
        feedback_dict = {
            "id": feedback.id,
            "manager_id": feedback.manager_id,
            "employee_id": feedback.employee_id,
            "strengths": feedback.strengths,
            "improvements": feedback.improvements,
            "sentiment": feedback.sentiment,
            "acknowledged": feedback.acknowledged,
            "acknowledged_at": feedback.acknowledged_at,
            "created_at": feedback.created_at,
            "updated_at": feedback.updated_at,
            "manager_name": feedback.manager.name,
            "employee_name": feedback.employee.name
        }
        result.append(schemas.FeedbackWithDetails(**feedback_dict))
    
    return result

@app.get("/api/feedback/{feedback_id}", response_model=schemas.FeedbackWithDetails)
async def get_feedback_by_id(
    feedback_id: uuid.UUID,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    feedback = crud.get_feedback(db, feedback_id)
    if not feedback:
        raise HTTPException(status_code=404, detail="Feedback not found")
    
    # Check permissions
    if current_user.role == models.UserRole.EMPLOYEE and feedback.employee_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    elif current_user.role == models.UserRole.MANAGER and feedback.manager_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Load related data
    manager = crud.get_user(db, feedback.manager_id)
    employee = crud.get_user(db, feedback.employee_id)
    
    feedback_dict = {
        "id": feedback.id,
        "manager_id": feedback.manager_id,
        "employee_id": feedback.employee_id,
        "strengths": feedback.strengths,
        "improvements": feedback.improvements,
        "sentiment": feedback.sentiment,
        "acknowledged": feedback.acknowledged,
        "acknowledged_at": feedback.acknowledged_at,
        "created_at": feedback.created_at,
        "updated_at": feedback.updated_at,
        "manager_name": manager.name,
        "employee_name": employee.name
    }
    
    return schemas.FeedbackWithDetails(**feedback_dict)

@app.put("/api/feedback/{feedback_id}", response_model=schemas.Feedback)
async def update_feedback(
    feedback_id: uuid.UUID,
    feedback_update: schemas.FeedbackUpdate,
    current_user: models.User = Depends(auth.require_role(models.UserRole.MANAGER)),
    db: Session = Depends(get_db)
):
    updated_feedback = crud.update_feedback(db, feedback_id, feedback_update, current_user.id)
    if not updated_feedback:
        raise HTTPException(status_code=404, detail="Feedback not found or access denied")
    
    return updated_feedback

@app.post("/api/feedback/{feedback_id}/acknowledge", response_model=schemas.Feedback)
async def acknowledge_feedback(
    feedback_id: uuid.UUID,
    current_user: models.User = Depends(auth.require_role(models.UserRole.EMPLOYEE)),
    db: Session = Depends(get_db)
):
    acknowledged_feedback = crud.acknowledge_feedback(db, feedback_id, current_user.id)
    if not acknowledged_feedback:
        raise HTTPException(status_code=404, detail="Feedback not found or access denied")
    
    return acknowledged_feedback

@app.delete("/api/feedback/{feedback_id}")
async def delete_feedback(
    feedback_id: uuid.UUID,
    current_user: models.User = Depends(auth.require_role(models.UserRole.MANAGER)),
    db: Session = Depends(get_db)
):
    success = crud.delete_feedback(db, feedback_id, current_user.id)
    if not success:
        raise HTTPException(status_code=404, detail="Feedback not found or access denied")
    
    return {"message": "Feedback deleted successfully"}

# Dashboard endpoints
@app.get("/api/analytics/dashboard")
async def get_dashboard_stats(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role == models.UserRole.MANAGER:
        return crud.get_manager_dashboard_stats(db, current_user.id)
    else:
        return crud.get_employee_dashboard_stats(db, current_user.id)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)