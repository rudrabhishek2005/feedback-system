# Feedback System Backend

A comprehensive Python backend for the lightweight feedback system built with FastAPI, SQLAlchemy, and PostgreSQL.

## 🚀 Features

### Core Functionality
- **JWT Authentication**: Secure token-based authentication with role-based access control
- **User Management**: Complete user CRUD operations with manager-employee relationships
- **Feedback System**: Structured feedback with strengths, improvements, and sentiment tracking
- **Role-based Access**: Strict separation between manager and employee permissions
- **Dashboard Analytics**: Comprehensive statistics and sentiment analysis
- **Database Migrations**: Alembic integration for schema management

### Security Features
- **Password Hashing**: Bcrypt password hashing for secure storage
- **JWT Tokens**: Secure token-based authentication with expiration
- **Role-based Authorization**: Endpoint-level permission controls
- **Data Isolation**: Users can only access their authorized data
- **Input Validation**: Comprehensive request validation with Pydantic

### API Features
- **RESTful Design**: Clean, intuitive API endpoints
- **OpenAPI Documentation**: Auto-generated API documentation
- **CORS Support**: Configured for frontend integration
- **Error Handling**: Comprehensive error responses
- **Health Checks**: System health monitoring endpoints

## 🏗️ Architecture

### Technology Stack
- **FastAPI**: Modern, fast web framework for building APIs
- **SQLAlchemy**: Powerful ORM for database operations
- **PostgreSQL**: Robust relational database
- **Alembic**: Database migration management
- **Pydantic**: Data validation and serialization
- **JWT**: Secure authentication tokens
- **Pytest**: Comprehensive testing framework

### Database Schema

```sql
-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('manager', 'employee')),
    manager_id UUID REFERENCES users(id),
    avatar_url TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Feedback table
CREATE TABLE feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    manager_id UUID NOT NULL REFERENCES users(id),
    employee_id UUID NOT NULL REFERENCES users(id),
    strengths TEXT NOT NULL,
    improvements TEXT NOT NULL,
    sentiment VARCHAR(20) NOT NULL CHECK (sentiment IN ('positive', 'neutral', 'negative')),
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### API Endpoints

#### Authentication
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user info
- `POST /api/auth/logout` - User logout

#### Users
- `POST /api/users` - Create new user (managers only)
- `GET /api/users/team` - Get team members (managers only)
- `GET /api/users/{user_id}` - Get user details

#### Feedback
- `POST /api/feedback` - Create feedback (managers only)
- `GET /api/feedback` - Get feedback (role-based filtering)
- `GET /api/feedback/{feedback_id}` - Get specific feedback
- `PUT /api/feedback/{feedback_id}` - Update feedback (managers only)
- `POST /api/feedback/{feedback_id}/acknowledge` - Acknowledge feedback (employees only)
- `DELETE /api/feedback/{feedback_id}` - Delete feedback (managers only)

#### Analytics
- `GET /api/analytics/dashboard` - Get dashboard statistics

## 🚀 Setup Instructions

### Prerequisites
- Python 3.11+
- PostgreSQL 15+
- Docker (optional)

### Local Development Setup

1. **Clone and navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your database credentials
   ```

5. **Set up PostgreSQL database**
   ```bash
   # Create database
   createdb feedback_db
   
   # Or using psql
   psql -c "CREATE DATABASE feedback_db;"
   ```

6. **Run database migrations**
   ```bash
   alembic upgrade head
   ```

7. **Seed the database with sample data**
   ```bash
   python seed_data.py
   ```

8. **Start the development server**
   ```bash
   uvicorn main:app --reload
   ```

The API will be available at `http://localhost:8000`

### Docker Setup

1. **Using Docker Compose (Recommended)**
   ```bash
   docker-compose up --build
   ```

   This will start both PostgreSQL and the backend service with automatic database setup.

2. **Manual Docker Build**
   ```bash
   # Build the image
   docker build -t feedback-backend .
   
   # Run with environment variables
   docker run -p 8000:8000 \
     -e DATABASE_URL=postgresql://user:pass@host:5432/feedback_db \
     -e SECRET_KEY=your-secret-key \
     feedback-backend
   ```

### Production Deployment

1. **Environment Variables**
   ```bash
   DATABASE_URL=postgresql://user:password@host:5432/feedback_db
   SECRET_KEY=your-super-secret-key-change-this-in-production
   ALGORITHM=HS256
   ACCESS_TOKEN_EXPIRE_MINUTES=30
   ENVIRONMENT=production
   ```

2. **Database Setup**
   ```bash
   # Run migrations
   alembic upgrade head
   
   # Create initial admin user (optional)
   python seed_data.py
   ```

3. **Start Production Server**
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
   ```

## 🧪 Testing

### Run Tests
```bash
# Install test dependencies
pip install pytest pytest-asyncio httpx

# Run all tests
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Run specific test file
pytest tests/test_main.py -v
```

### Test Coverage
The test suite covers:
- Authentication endpoints
- User management
- Feedback CRUD operations
- Role-based access control
- Dashboard analytics
- Error handling

## 📊 API Documentation

### Interactive Documentation
- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`

### Sample API Calls

#### Login
```bash
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "sarah@company.com", "password": "password"}'
```

#### Create Feedback
```bash
curl -X POST "http://localhost:8000/api/feedback" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "employee_id": "employee-uuid",
    "strengths": "Excellent problem-solving skills",
    "improvements": "Could improve time management",
    "sentiment": "positive"
  }'
```

#### Get Dashboard Stats
```bash
curl -X GET "http://localhost:8000/api/analytics/dashboard" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 🔒 Security Considerations

### Authentication & Authorization
- JWT tokens with configurable expiration
- Role-based access control at endpoint level
- Password hashing with bcrypt
- Secure token validation

### Data Protection
- Input validation with Pydantic schemas
- SQL injection prevention with SQLAlchemy ORM
- CORS configuration for frontend integration
- Environment variable management for secrets

### Access Control
- Managers can only access their team members' data
- Employees can only access their own feedback
- Strict permission checks on all endpoints
- Data isolation at database query level

## 🚀 Performance Optimizations

### Database
- Strategic indexes on frequently queried columns
- Efficient relationship loading with SQLAlchemy
- Connection pooling for concurrent requests
- Query optimization for dashboard analytics

### API
- Async/await support with FastAPI
- Efficient serialization with Pydantic
- Minimal data transfer with selective field loading
- Proper HTTP status codes and error handling

## 📈 Monitoring & Logging

### Health Checks
- `/health` endpoint for system monitoring
- Database connection validation
- Service dependency checks

### Logging
- Structured logging with configurable levels
- Request/response logging for debugging
- Error tracking and reporting
- Performance metrics collection

## 🔧 Configuration

### Environment Variables
```bash
# Database
DATABASE_URL=postgresql://user:pass@host:5432/db

# Security
SECRET_KEY=your-secret-key
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Environment
ENVIRONMENT=development|production
```

### Database Configuration
- Connection pooling settings
- Migration management with Alembic
- Backup and recovery procedures
- Performance tuning parameters

## 📝 Demo Accounts

The seed script creates the following demo accounts:

**Managers:**
- sarah@company.com (password: password)
- david@company.com (password: password)

**Employees:**
- mike@company.com (password: password)
- emma@company.com (password: password)
- lisa@company.com (password: password)

## 🤝 Contributing

### Development Workflow
1. Create feature branch
2. Write tests for new functionality
3. Implement features with proper error handling
4. Update documentation
5. Run test suite
6. Submit pull request

### Code Standards
- Follow PEP 8 style guidelines
- Use type hints throughout
- Write comprehensive docstrings
- Maintain test coverage above 80%
- Use meaningful variable and function names

This backend provides a robust, scalable foundation for the feedback system with comprehensive security, testing, and documentation.