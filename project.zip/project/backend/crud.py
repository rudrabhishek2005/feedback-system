from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, func
from typing import List, Optional
import models
import schemas
from auth import get_password_hash
import uuid

# User CRUD operations
def create_user(db: Session, user: schemas.UserCreate) -> models.User:
    hashed_password = get_password_hash(user.password)
    db_user = models.User(
        name=user.name,
        email=user.email,
        password_hash=hashed_password,
        role=user.role,
        manager_id=user.manager_id,
        avatar_url=user.avatar_url
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user(db: Session, user_id: uuid.UUID) -> Optional[models.User]:
    return db.query(models.User).filter(models.User.id == user_id).first()

def get_user_by_email(db: Session, email: str) -> Optional[models.User]:
    return db.query(models.User).filter(models.User.email == email).first()

def get_team_members(db: Session, manager_id: uuid.UUID) -> List[models.User]:
    return db.query(models.User).filter(models.User.manager_id == manager_id).all()

def update_user(db: Session, user_id: uuid.UUID, user_update: schemas.UserUpdate) -> Optional[models.User]:
    db_user = get_user(db, user_id)
    if not db_user:
        return None
    
    update_data = user_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_user, field, value)
    
    db.commit()
    db.refresh(db_user)
    return db_user

# Feedback CRUD operations
def create_feedback(db: Session, feedback: schemas.FeedbackCreate, manager_id: uuid.UUID) -> models.Feedback:
    db_feedback = models.Feedback(
        manager_id=manager_id,
        employee_id=feedback.employee_id,
        strengths=feedback.strengths,
        improvements=feedback.improvements,
        sentiment=feedback.sentiment
    )
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

def get_feedback(db: Session, feedback_id: uuid.UUID) -> Optional[models.Feedback]:
    return db.query(models.Feedback).filter(models.Feedback.id == feedback_id).first()

def get_feedback_for_employee(db: Session, employee_id: uuid.UUID) -> List[models.Feedback]:
    return db.query(models.Feedback)\
        .filter(models.Feedback.employee_id == employee_id)\
        .options(joinedload(models.Feedback.manager))\
        .order_by(models.Feedback.created_at.desc())\
        .all()

def get_feedback_by_manager(db: Session, manager_id: uuid.UUID) -> List[models.Feedback]:
    return db.query(models.Feedback)\
        .filter(models.Feedback.manager_id == manager_id)\
        .options(joinedload(models.Feedback.employee))\
        .order_by(models.Feedback.created_at.desc())\
        .all()

def update_feedback(db: Session, feedback_id: uuid.UUID, feedback_update: schemas.FeedbackUpdate, manager_id: uuid.UUID) -> Optional[models.Feedback]:
    db_feedback = db.query(models.Feedback).filter(
        and_(models.Feedback.id == feedback_id, models.Feedback.manager_id == manager_id)
    ).first()
    
    if not db_feedback:
        return None
    
    update_data = feedback_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_feedback, field, value)
    
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

def acknowledge_feedback(db: Session, feedback_id: uuid.UUID, employee_id: uuid.UUID) -> Optional[models.Feedback]:
    db_feedback = db.query(models.Feedback).filter(
        and_(models.Feedback.id == feedback_id, models.Feedback.employee_id == employee_id)
    ).first()
    
    if not db_feedback:
        return None
    
    db_feedback.acknowledged = True
    db_feedback.acknowledged_at = func.now()
    
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

def delete_feedback(db: Session, feedback_id: uuid.UUID, manager_id: uuid.UUID) -> bool:
    db_feedback = db.query(models.Feedback).filter(
        and_(models.Feedback.id == feedback_id, models.Feedback.manager_id == manager_id)
    ).first()
    
    if not db_feedback:
        return False
    
    db.delete(db_feedback)
    db.commit()
    return True

# Dashboard and Analytics
def get_manager_dashboard_stats(db: Session, manager_id: uuid.UUID) -> schemas.ManagerDashboardStats:
    # Get team members count
    team_count = db.query(models.User).filter(models.User.manager_id == manager_id).count()
    
    # Get feedback stats for the team
    team_feedback = db.query(models.Feedback)\
        .join(models.User, models.Feedback.employee_id == models.User.id)\
        .filter(models.User.manager_id == manager_id)\
        .all()
    
    total_feedback = len(team_feedback)
    acknowledged_feedback = sum(1 for f in team_feedback if f.acknowledged)
    pending_feedback = total_feedback - acknowledged_feedback
    
    # Sentiment counts
    sentiment_counts = schemas.SentimentCount()
    for feedback in team_feedback:
        if feedback.sentiment == models.SentimentType.POSITIVE:
            sentiment_counts.positive += 1
        elif feedback.sentiment == models.SentimentType.NEGATIVE:
            sentiment_counts.negative += 1
        else:
            sentiment_counts.neutral += 1
    
    return schemas.ManagerDashboardStats(
        team_members_count=team_count,
        total_feedback=total_feedback,
        acknowledged_feedback=acknowledged_feedback,
        pending_feedback=pending_feedback,
        sentiment_counts=sentiment_counts
    )

def get_employee_dashboard_stats(db: Session, employee_id: uuid.UUID) -> schemas.EmployeeDashboardStats:
    # Get feedback stats for the employee
    employee_feedback = db.query(models.Feedback)\
        .filter(models.Feedback.employee_id == employee_id)\
        .all()
    
    total_feedback = len(employee_feedback)
    acknowledged_feedback = sum(1 for f in employee_feedback if f.acknowledged)
    pending_feedback = total_feedback - acknowledged_feedback
    
    # Sentiment counts
    sentiment_counts = schemas.SentimentCount()
    for feedback in employee_feedback:
        if feedback.sentiment == models.SentimentType.POSITIVE:
            sentiment_counts.positive += 1
        elif feedback.sentiment == models.SentimentType.NEGATIVE:
            sentiment_counts.negative += 1
        else:
            sentiment_counts.neutral += 1
    
    return schemas.EmployeeDashboardStats(
        total_feedback=total_feedback,
        acknowledged_feedback=acknowledged_feedback,
        pending_feedback=pending_feedback,
        sentiment_counts=sentiment_counts
    )