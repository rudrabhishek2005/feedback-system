"""
Seed script to populate the database with initial data
"""
from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models
import schemas
import crud
from auth import get_password_hash

def create_seed_data():
    # Create tables
    models.Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    
    try:
        # Create managers
        manager1 = models.User(
            name="Sarah Johnson",
            email="sarah@company.com",
            password_hash=get_password_hash("password"),
            role=models.UserRole.MANAGER,
            avatar_url="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
        )
        
        manager2 = models.User(
            name="David Wilson",
            email="david@company.com",
            password_hash=get_password_hash("password"),
            role=models.UserRole.MANAGER,
            avatar_url="https://images.pexels.com/photos/697509/pexels-photo-697509.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
        )
        
        db.add(manager1)
        db.add(manager2)
        db.commit()
        db.refresh(manager1)
        db.refresh(manager2)
        
        # Create employees
        employee1 = models.User(
            name="Mike Chen",
            email="mike@company.com",
            password_hash=get_password_hash("password"),
            role=models.UserRole.EMPLOYEE,
            manager_id=manager1.id,
            avatar_url="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
        )
        
        employee2 = models.User(
            name="Emma Davis",
            email="emma@company.com",
            password_hash=get_password_hash("password"),
            role=models.UserRole.EMPLOYEE,
            manager_id=manager1.id,
            avatar_url="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
        )
        
        employee3 = models.User(
            name="Lisa Anderson",
            email="lisa@company.com",
            password_hash=get_password_hash("password"),
            role=models.UserRole.EMPLOYEE,
            manager_id=manager2.id,
            avatar_url="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
        )
        
        db.add(employee1)
        db.add(employee2)
        db.add(employee3)
        db.commit()
        db.refresh(employee1)
        db.refresh(employee2)
        db.refresh(employee3)
        
        # Create sample feedback
        feedback1 = models.Feedback(
            manager_id=manager1.id,
            employee_id=employee1.id,
            strengths="Mike consistently delivers high-quality code and shows excellent problem-solving skills. His attention to detail and ability to work collaboratively make him a valuable team member.",
            improvements="Could benefit from taking more initiative in meetings and sharing technical insights with the team. Consider leading a small project to develop leadership skills.",
            sentiment=models.SentimentType.POSITIVE,
            acknowledged=True
        )
        
        feedback2 = models.Feedback(
            manager_id=manager1.id,
            employee_id=employee2.id,
            strengths="Emma has shown remarkable growth in her communication skills and has become the go-to person for client interactions. Her positive attitude is infectious.",
            improvements="Technical skills could use some strengthening, particularly in backend development. Recommend additional training or pair programming sessions.",
            sentiment=models.SentimentType.POSITIVE,
            acknowledged=False
        )
        
        feedback3 = models.Feedback(
            manager_id=manager2.id,
            employee_id=employee3.id,
            strengths="Lisa demonstrates strong analytical thinking and has significantly improved our testing processes. Her documentation is thorough and well-organized.",
            improvements="Time management could be improved. Sometimes takes longer than expected on tasks. Would benefit from breaking down large tasks into smaller, manageable chunks.",
            sentiment=models.SentimentType.NEUTRAL,
            acknowledged=True
        )
        
        db.add(feedback1)
        db.add(feedback2)
        db.add(feedback3)
        db.commit()
        
        print("✅ Seed data created successfully!")
        print("\nDemo accounts:")
        print("Managers:")
        print("  - sarah@company.com (password: password)")
        print("  - david@company.com (password: password)")
        print("Employees:")
        print("  - mike@company.com (password: password)")
        print("  - emma@company.com (password: password)")
        print("  - lisa@company.com (password: password)")
        
    except Exception as e:
        print(f"❌ Error creating seed data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_seed_data()